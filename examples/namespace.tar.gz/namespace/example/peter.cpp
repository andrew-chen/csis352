// file: peter.cpp
#include <iostream>
#include "peter.h"
using std::cout;
void peter::read()
{
   cout << "This is Peter's read function\n";
}

void peter::write()
{
   cout << "This is Peter's write function\n";
}
