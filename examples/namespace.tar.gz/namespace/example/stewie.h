// file: stewie.h
namespace stewie
{
   void read();
   void write();
};
