// This used for experimenting in class

#include <iostream>
using namespace std;

namespace first
{
   int x=5;
}
namespace second
{
   int x=10;
}

int main()
{
   cout << x << endl;
   return 0;
}
